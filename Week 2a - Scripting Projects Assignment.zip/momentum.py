import math
mass = float(input("Enter the mass of the object (in kilograms): "))
velocity = float(input("Enter the velocity of the object (in meters per second): "))
momentum = mass * velocity
print("The momentum of the object is:", momentum, "kg·m/s")
