edge = int(input("Enter the length of the edge: "))
surfaceArea = 6 * (edge ** 2)
print("the surface area of the cube is:", surfaceArea)

