import math

def main():
    print("Welcome to the Reverse Guessing Game!")
    print("Think of a number between two bounds and I'll try to guess it.")
    
    
    low = int(input("Enter the lowest possible number: "))
    high = int(input("Enter the highest possible number: "))
    
    
    max_guesses = math.ceil(math.log2(high - low + 1))
    print(f"\nI will guess your number in at most {max_guesses} tries. Please respond with 'higher', 'lower', or 'correct'.\n")
    
    guesses = 0
    current_low = low
    current_high = high

    while guesses < max_guesses:
        guess = (current_low + current_high) // 2
        print(f"My guess #{guesses + 1}: {guess}")
        response = input("Is your number higher, lower, or correct? ").strip().lower()

        guesses += 1

        if response == "correct":
            print(f"\nYay! I guessed your number in {guesses} tries.")
            return
        elif response == "higher":
            if guess == current_high:
                print("Don't cheat! There's no number higher in the range.")
                return
            current_low = guess + 1
        elif response == "lower":
            if guess == current_low:
                print("Don't cheat! There's no number lower in the range.")
                return
            current_high = guess - 1
        else:
            print("Invalid response. Please type 'higher', 'lower', or 'correct'.")
            guesses -= 1

        if current_low > current_high:
            print("Your responses are inconsistent. Are you trying to cheat?")
            return

    print("\nHmm... I couldn't guess it within the allowed attempts. Are you sure you answered honestly?")

if __name__ == "__main__":
    main()
