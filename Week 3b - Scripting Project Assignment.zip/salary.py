def main():
    print("Teacher Salary Schedule Generator\n")
    
 
    starting_salary = float(input("Enter the starting salary (e.g., 30000): "))
    percent_increase = float(input("Enter the annual percentage increase (e.g., 2 for 2%): "))
    years = int(input("Enter the number of years in the schedule (e.g., 10): "))

    print("\nSalary Schedule")
    print("{:<10} {:>15}".format("Year", "Salary"))
    print("-" * 26)
          
    salary = starting_salary

    
    for year in range(1, years + 1):
        print("{:<10} ${:>14,.2f}".format(year, salary))
        salary += salary * (percent_increase / 100)
if __name__ == "__main__":
    main()
