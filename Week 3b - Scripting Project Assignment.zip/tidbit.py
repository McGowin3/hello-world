def main():
    print("TidBit Computer Store Credit Plan Payment Schedule\n")

    
    purchase_price = float(input("Enter the purchase price: $"))

    
    down_payment = purchase_price * 0.10
    annual_interest_rate = 0.12
    monthly_payment = purchase_price * 0.05

    
    balance = purchase_price - down_payment
    month = 1

    
    print("\n{:<8} {:>12} {:>12} {:>12} {:>12} {:>15}".format(
        "Month", "Balance", "Interest", "Principal", "Payment", "Remaining"))
    print("-" * 75)

    
    while balance > 0:
        interest = balance * (annual_interest_rate / 12)
        principal = monthly_payment - interest

      
        if principal > balance:
            principal = balance
            monthly_payment = interest + principal

        remaining = balance - principal

        print("{:<8} ${:>11.2f} ${:>11.2f} ${:>11.2f} ${:>11.2f} ${:>14.2f}".format(
            month, balance, interest, principal, monthly_payment, remaining))

        balance = remaining
        month += 1

if __name__ == "__main__":
    main()
