print("Population Growth Predictor")

initial_population = float(input("Enter the initial number of organisms: "))
growth_rate = float(input("Enter the growth rate (e.g., 2 for doubling): "))
growth_period = float(input("Enter the number of hours to achieve the growth rate: "))
total_hours = float(input("Enter the total number of hours the population grows: "))

number_of_cycles = total_hours // growth_period

    
final_population = initial_population * (growth_rate ** number_of_cycles)

   
print(f"\nAfter {int(total_hours)} hours, the population will be approximately {int(final_population)} organisms.")
