a = float(input("Enter the length of the first side: "))
b = float(input("Enter the length of the second side: "))
c = float(input("Enter the length of the third side: "))
if a <= 0 or b <= 0 or c <= 0:
        print("Side lengths must be positive numbers.")
elif a + b <= c or a + c <= b or b + c <= a:
        print("The given lengths do not form a valid triangle.")
elif a == b and b == c:
        print("The triangle is equilateral.")
else:
        print("The triangle is not equilateral.")

