initial_height = float(input("Enter the initial height (in feet): "))
bounciness_index = float(input("Enter the bounciness index (0 < index < 1): "))
number_of_bounces = int(input("Enter the number of times the ball bounces: "))
total_distance = initial_height
height = initial_height

for i in range(number_of_bounces):
        height *= bounciness_index
        total_distance += 2 * height

print(f"\nTotal distance traveled after {number_of_bounces} bounces: {total_distance:.2f} feet")
