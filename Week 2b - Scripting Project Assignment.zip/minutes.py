years = float(input("Enter the number of years: "))
minutes = years * 365 * 24 * 60
print(f"There are {minutes:.2f} minutes in {years} years.")
